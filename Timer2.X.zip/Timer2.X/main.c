/*
 * File:   main.c
 * Author: Administrator
 *
 * Created on 12 December, 2020, 7:37 PM
 */

// CONFIG
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>

#define _XTAL_FREQ 20000000 //define crystal frequency to 20MHz
void timer2delay(void);
void seq(char get)
{
{
for (int j=0; j<=7; j++) 
{
PORTD = get << j; //LED move Left Sequence 
timer2delay();
}
for (int j=7; j>=0; j--)
{
PORTD = get << j; //LED move Left Sequence 
timer2delay();
} 
}
}

void main(void) 
{
TRISC0 = 1; //Define PORTC pin 0 is used as input for push button.
TRISD = 0x00; //Instruct the MCU that all pins are output 
PORTD=0x00; //Define PORT D as output
while(1) //define While loop for continuous operation
{
    if (RC0==0)//if PORTC pin 0 = 1
    {
    
        seq(1); //call function 1 with parameter 1 
        seq(3); //call function 3 with parameter 3
        seq(7); //call function 7 with parameter 7
        seq(15); //call function 4 with parameter 15
        
        while(RC0==1) //If button is still pressed
        {
            PORTD=0xFF; //Turn ON all LEDs
        }
    }
}
}

void timer2delay(void){     //500ms delay
   
     unsigned int i;
  T2CON|=(1<<2);        //timer2 on
  for(i=0;i<2000;i++)   ////500us * 2000=1000000us=1sec 
  {
    while(!TMR2IF);  
    TMR2IF=0;
  }
}